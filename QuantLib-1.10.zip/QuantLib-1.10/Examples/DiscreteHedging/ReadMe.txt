
This is an example on using QuantLib Montecarlo framework.

It computes profit and loss of a discrete interval hedging strategy and compares
with the results of Derman & Kamal's (Goldman Sachs Equity Derivatives Research)
Research Note: "When You Cannot Hedge Continuously: The Corrections to
Black-Scholes"
http://www.ederman.com/emanuelderman/GSQSpapers/when_you_cannot_hedge.pdf
