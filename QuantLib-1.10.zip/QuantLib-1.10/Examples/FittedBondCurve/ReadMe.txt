This example fits a discount curve over a set of bonds with a number
of methods.
