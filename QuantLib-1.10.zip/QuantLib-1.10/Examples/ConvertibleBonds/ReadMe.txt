This example evaluates convertible bond values
