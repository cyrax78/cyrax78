Forward-rate agreement valuation example.
