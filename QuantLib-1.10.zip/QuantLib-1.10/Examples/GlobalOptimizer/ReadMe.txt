Examples showing how to use the global optimizers in QuantLib.
