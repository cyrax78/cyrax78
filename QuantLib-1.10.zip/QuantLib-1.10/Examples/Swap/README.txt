
This example shows how to set up a Term Structure and then price a simple swap
